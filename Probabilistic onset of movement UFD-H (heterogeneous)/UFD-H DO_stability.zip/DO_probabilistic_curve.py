# -*- coding: utf-8 -*-
"""
19.01.2022
Onset of stability for urban debris.
@author: D. Valero
"""

import time
#import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

# In-house library to support auxiliary calculations
import faux as fa

start = time.time()

# For reproducibility
np.random.seed(120589)
Nr = 1000 # Number of Monte Carlo draws

folder = "DO-input"

Lx_list = fa.get_var(folder, Nr, "Lx")
Ly_list = fa.get_var(folder, Nr, "Ly")
# No need to import Lz, since we define as a fraction of Ly
# Lz_list = fa.get_var(folder, Nr, "Lz")
Lz_list = np.random.uniform(0.10,1,Nr) * Ly_list
Lx_list, Ly_list, Lz_list = fa.find_stable_config(Lx_list, Ly_list, Lz_list) # verified

fA_list = fa.get_var(folder, Nr, "fA")
fV_list = fa.get_var(folder, Nr, "fV")
# rhos =    fa.get_var(folder, Nr, "rhos")
# rhob =    rhos* fV_list
M_list =  fa.get_var(folder, Nr, "M")     # rhob*Lx_list*Ly_list*Lz_list
Cd_list = fa.get_var(folder, Nr, "Cd")
mu_list = fa.get_var(folder, Nr, "mu")

# Not applicable here:
zc_list = np.random.uniform(0.0,0.0,Nr)
# fA_RMSE_list = np.random.uniform(0.0,0.0,Nr)
characteristics = [Lx_list, Ly_list, Lz_list, fA_list, fV_list,
                   M_list, Cd_list, mu_list]


# # h, vx as key parameters ----------------------------------------------------
nh = 200; nv = 400

# ----------------------------------------------------------------------------
# Start calculations ---------------------------------------------------------

hcrit_flot = np.zeros(Nr)
vcrit_sliding = np.zeros([Nr,nv])
hcrit_sliding = np.zeros([Nr,nv])
vcrit_toppling = np.zeros([Nr,nv])
hcrit_toppling = np.zeros([Nr,nv])

for k in range(0, Nr):
    [hcrit_flot[k], vcrit_sliding[k,:], hcrit_sliding[k,:], vcrit_toppling[k,:], hcrit_toppling[k,:]] = \
        fa.get_stability_curves_debris(M_list[k],Lx_list[k],Ly_list[k],Lz_list[k],
                                  zc_list[k],Cd_list[k],mu_list[k],
                                  fA_list[k], fV_list[k], nh, nv)
    
    if (k % 100) == 0:
        print("Stability curve number: ", k)

# We do not know if sliding or toppling will dominate. Thus, check the most unstable one...
hcrit = np.zeros_like(hcrit_sliding)
for i in range(0, nv):
    for k in range(0, Nr):
        hcrit[k, i] = np.nanmin([hcrit_sliding[k,i], hcrit_toppling[k,i]])

# PLOTTING --------------------------------------------------------------------        

# Fig. opts.
plt.figure(figsize=(4,4))

plt.plot(vcrit_sliding[k,0], hcrit[k,0], ls='-', c='k', zorder=7, alpha=0.05,
         lw=2, label='Stability curve')
# plt.plot(vcrit_toppling[k,0], hcrit_toppling[k,0], ls='--', c='b', zorder=7, alpha=0.05,
#           label='Toppling')

for k in range(1,Nr):
    # Flotation ----
    # plt.scatter(0, hcrit_flot[k], marker= 'o', s=80, zorder=7, alpha=0.2,
    #             edgecolor='k', facecolor='w', label='Flotation')
    # Sliding ----
    plt.plot(vcrit_sliding[k,:], hcrit[k,:], ls='-', c='k', zorder=7, alpha=0.05,
             lw=2)
    # Toppling ----
    # plt.plot(vcrit_toppling[k,:], hcrit_toppling[k,:], ls='--', c='b', zorder=7, alpha=0.05)

# imed = fa.find_median_curve(vcrit_sliding, hcrit)
# plt.plot(vcrit_sliding[imed,:], hcrit[imed,:], ls='--', c='r', zorder=7, 
#          lw=2, label="Median curve")

#hperc500 = np.percentile(hcrit, 50.0, axis=0)
hperc500 = fa.nan_percentiles_bias_corr(vcrit_sliding, hcrit, 50)
plt.plot(vcrit_sliding[0,:], hperc500, ls='-.', c='r', zorder=7, 
         lw=2, label="50 % percentile")
# hperc025 = np.percentile(hcrit, 2.5, axis=0)
hperc025 = fa.nan_percentiles_bias_corr(vcrit_sliding, hcrit, 2.5)
hperc975 = np.percentile(hcrit, 97.5, axis=0)
#hperc975 = fa.nan_percentiles_bias_corr(vcrit_sliding, hcrit, 97.5)
plt.plot(vcrit_sliding[0,:], hperc025, ls=':', c='r', zorder=7, 
         lw=2)
plt.plot(vcrit_sliding[0,:], hperc975, ls=':', c='r', zorder=7, 
         lw=2, label="95 % uncertainty bounds")



# plt.plot(np.mean(vcrit_sliding,0), np.mean(hcrit,0), ls='-.', c='g', zorder=7, 
#          lw=2, label="Sliding - Mean curve")



plt.ylabel('$h$ (m)')
plt.xlabel('$v$ (m/s)')
plt.legend(loc='best')

plt.xticks(np.arange(0, 9.0+1, 1.0))
plt.xlim(0, 9)
plt.ylim([0,1.5])

# Save the plot and the data now!
folder_s = "DO-results"
np.save(folder_s +"\\"+"DO_characteristics.npy", characteristics)
np.save(folder_s +"\\"+"DO_vcrit.npy",vcrit_sliding)
np.save(folder_s +"\\"+"DO_hcrit.npy",hcrit)
np.save(folder_s +"\\"+"DO_vcrit_sliding.npy",vcrit_sliding)
np.save(folder_s +"\\"+"DO_hcrit_sliding.npy",hcrit_sliding)
np.save(folder_s +"\\"+"DO_vcrit_toppling.npy",vcrit_toppling)
np.save(folder_s +"\\"+"DO_hcrit_toppling.npy",hcrit_toppling)
plt.savefig(folder_s +"\\"+'DO_curve.pdf', dpi=600, format='pdf',  bbox_inches='tight')
plt.savefig(folder_s +"\\"+'DO_curve.png', dpi=600, format='png',  bbox_inches='tight')
plt.savefig(folder_s +"\\"+'DO_curve.svg', dpi=600, format='svg',  bbox_inches='tight')

end = time.time()
print("Elapsed time: ", end-start)

plt.show()