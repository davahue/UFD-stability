# -*- coding: utf-8 -*-
"""
19.01.2022

@author: D. Valero

"""
import csv
import numpy as np
from scipy import interpolate
from scipy.special import comb

from matplotlib import pyplot as plt

# Fitting functions -----------------------------------------------------------
# Functions for Lx vs Ly
def OneMinusExp(x, A, B):
    y = A*(1-np.exp(-B*x))
    return y

def Linear(x, A, B):
    y = A*x + B
    return y

# Error estimation
def RMSE(predictions, targets):
    """
    Root-Mean Squared Error estimation.
    Same units as receiveing variable.
    """
    return np.sqrt(((predictions - targets) ** 2).mean())

# auxiliary functions --------------------------------------------------------

def zero_finding(arr, v, h):
    """
    Inputs a 2D array with RHS-LHS and finds the points where its zero.
    
    The x-variable is velocity:
        v = np.linspace(0, 9.5, nv)
    and then we find h at which RHS-LHS == 0.
    
    The method should be robust vs nan.
    
    This method differs from zero_finding() on the way it handles when no
    crossing happens.
    
    Tested against plt.contour function.
    """
    
    [nx, ny] = np.shape(arr)
    h_stab = np.zeros(nx)
    # print(nx) # This is v-direction
    # print(ny)
    
    for i in range(nx):
        jleft = np.where(np.diff(np.sign(arr[i,:])))[0][0]
        jright = jleft+1 # next index, arr is negative
        
        y1 = arr[i,jleft]
        y2 = arr[i,jright]
        
        X = y1/(y1-y2)
        
        h_stab[i] = h[jleft] +X*(h[jright] - h[jleft])
    
    
    return h_stab


def zero_finding2(arr, v, h):
    """
    Inputs a 2D array with RHS-LHS and finds the points where its zero.
    
    The x-variable is velocity:
        v = np.linspace(0, 9.5, nv)
    and then we find h at which RHS-LHS == 0.
    
    The method should be robust vs nan.
    
    Tested against plt.contour function.
    """
    
    [nx, ny] = np.shape(arr)
    h_stab = np.zeros(nx)
    # print(nx) # This is v-direction
    # print(ny)
    
    for i in range(nx):
        
        #What if no zero crossing?
        if (True in (arr[i,:] < 0) )*( False in (arr[i,:] < 0)):
            """
            This means, there is one positive and one negative, at least.
            We need one positive and one negative to have a zero crossing.
            """
           # Interpolation:
            jleft = np.where(np.diff(np.sign(arr[i,:])))[0][0]
            jright = jleft+1 # next index, arr is negative
            
            y1 = arr[i,jleft]
            y2 = arr[i,jright]
            
            X = y1/(y1-y2)
            
            h_stab[i] = h[jleft] +X*(h[jright] - h[jleft])
        else:
            """
            This means, there is no positive, or no negative. We need at least
            a positive and a negative to have a zero crossing.
            """

            h_stab[i] = np.nan
    
    return h_stab


def find_median_curve(XX,YY):
    """
    Takes a list of lines, and finds the median one based on the
    concept of depth of data.
    Input:
        XX: x-data
        YY: y-data
    This function transforms data on equally sized and then computes the depth
    The line with larger depth represents the median, as stated by:
        Sara López-Pintado & Juan Romo (2009) On the
        Concept of Depth for Functional Data, Journal of the American
        Statistical Association, 104:486, 718-734, DOI: 10.1198/jasa.2009.0108
    """
    N = len(YY)
    M = [] # number of elements of each hydrograph
    for i in range(0,N):
        M.append(len(YY[i]))
    
    Data_grid = np.zeros([N,np.max(M)])
    xgrid = np.linspace(0,1,np.max(M)) # poitns to interpolate in.
    for i in range(0,N):
        xdata = XX[i]
        ydata = YY[i]
        
        finterp = interpolate.interp1d(xdata, ydata, kind='linear')
        for j in range(0,np.max(M)):
            Data_grid[i,j] = finterp(xgrid[j])
    """
    # Verification plot -- verified 03/08/2021
    plt.figure()
    for i in range(0,N):
        
        plt.plot(xgrid, NHydrograph_grid[i,:],
                 c='k', alpha=0.075)
    """
    """
    Data is now ready (same length), we can obtain the depth. Depth defined
    as per:    
    statsmodels.graphics.functional.banddepth(data, method='MBD')
    """
    # The lines below must be credited to statsmodels.
    # See band depth: https://www.statsmodels.org/dev/_modules/statsmodels/graphics/functional.html#banddepth
    n, p = Data_grid.shape
    rv = np.argsort(Data_grid, axis=0)
    rmat = np.argsort(rv, axis=0) + 1
    # method: BD2
    down = np.min(rmat, axis=1) - 1
    up = n - np.max(rmat, axis=1)
    depth = (up * down + n - 1) / comb(n, 2)
    
    # The median curve is that holding maximum depth, see: Neto The Concept of
    # Depth in Statistics
    # This is also stated in: Sara López-Pintado & Juan Romo (2009) On the
    # Concept of Depth for Functional Data, Journal of the American
    # Statistical Association, 104:486, 718-734, DOI: 10.1198/jasa.2009.0108
    i_med = np.argmax(depth)
    
    return i_med

def compute_stable(V1_vcrit, V1_hcrit, hw):
    """
    This function computes how many curves provide a stable configuration for
    each velocity, and a given water depth (hw).

    Parameters
    ----------
    V1_vcrit : velocity points of the stability curves.
    V1_hcrit : depths leading to unstable flow-vehicle configurations. Here 
        np.nan may exist.

    Returns
    -------
    unstable_percent : percentage of nonnan.

    """
    nx, ny = np.shape(V1_hcrit)
    
    count_stable_per_v = np.zeros(ny)
            # nx - np.sum(V1_hcrit[:,j]>hw)    
    for j in range(0,ny):

        # for a fixed velocity: "j", is a debris stable? yes, if hcrit > h
        # Now, beware, np.nan always are false in a comparison.
        # Yet, a np.nan means the object is stable for any depth.
        # so, it is easier to compute the unstable: V1_hcrit[:,j]<hw
        
        count_UNstable_per_v = np.sum(V1_hcrit[:,j]<hw)
        # consequently:
        count_stable_per_v[j] = nx - count_UNstable_per_v
        
    stable_percent = 100*count_stable_per_v/nx
    
    return stable_percent


def compute_nonnan_percent(V1_vcrit, V1_hcrit):
    """
    This function computes how many non-nan are in the stability curves. Nan 
    numbers correspond to calculations where no value of h vs v triggered an
    instability.

    Parameters
    ----------
    V1_vcrit : velocity points of the stability curves.
    V1_hcrit : depths leading to unstable flow-vehicle configurations. Here 
        np.nan may exist.

    Returns
    -------
    nonnan_percent : percentage of nonnan.

    """
    nx, ny = np.shape(V1_hcrit)
    
    count_nonnan_per_v = np.zeros(ny)
    
    for j in range(0,ny):
        # Count how many values are NOT nan:
        count_nonnan_per_v[j] = np.count_nonzero(~np.isnan(V1_hcrit[:,j]))
        
    # plt.plot(V1_vcrit[0,:], count_nonnan_per_v/nx) 
    # plt.xlabel("$v$ (m/s)")      
    # plt.ylabel("% of non-nan data (-)")     
    
    nonnan_percent = 100*count_nonnan_per_v/nx
    
    return nonnan_percent


def show_nonnan_percent(V1_vcrit, V1_hcrit):
    """
    This function checks how many non-nan are in the stability curves.

    Parameters
    ----------
    V1_vcrit : velocity points of the stability curves.
    V1_hcrit : depths leading to unstable flow-vehicle configurations. Here 
        np.nan may exist.

    Returns
    -------
    None.

    """
    nx, ny = np.shape(V1_hcrit)
    
    count_nonnan_per_v = np.zeros(ny)
    
    for j in range(0,ny):
        count_nonnan_per_v[j] = np.count_nonzero(~np.isnan(V1_hcrit[:,j]))
        
    plt.plot(V1_vcrit[0,:], count_nonnan_per_v/nx) 
    plt.xlabel("$v$ (m/s)")      
    plt.ylabel("% of non-nan data (-)")      
        
    return

def nan_percentiles_bias_corr(V1_vcrit, V1_hcrit, Xth):
    """
    This function obtains the nanpercentiles assuming that all nan correspond 
    to very high depth values (thus, biased).

    Parameters
    ----------
    V1_vcrit : velocity points of the stability curves.
    V1_hcrit : depths leading to unstable flow-vehicle configurations. Here 
        np.nan may exist.
    Xth : percentiled seeked.

    Returns
    -------
    perc : curve corresponding to the corrected-Xth percentile.

    """
    nx, ny = np.shape(V1_hcrit)
    
    count_nonnan_per_v = np.zeros(ny)
    Xth_corr = np.zeros(ny)
    
    perc = np.ones(ny)*np.nan
    
    for j in range(0,ny):
        # first, count how many values are not a NAN:
        count_nonnan_per_v[j] = np.count_nonzero(~np.isnan(V1_hcrit[:,j]))
        
        """
        If I am not correcting, given the top-missing data, Xth would be indeed
        calculating the Xth*count_nonnan_per_v/nx percentile. Thus, seraching 
        for Xth is wrong; i.e.: Xthwrong = Xth * count_nonnan_per_v/nx
        which means: 
            Xth = Xthwrong*nx/count_nonnan_per_v
        """
        
        if count_nonnan_per_v[j] == 0: # There is no non-nan value remaining!!
            Xth_corr[j] = np.nan
            perc[j] = np.nan
        else: # There are a few real values. Let's correct the percentile for missing-top values.
            Xth_corr[j] = Xth*nx/count_nonnan_per_v[j]
            
            if Xth_corr[j]>=75: # 100: # Oh, oh! Not many values remaining...
                Xth_corr[j] = np.nan
                perc[j] = np.nan
            else: # all good.
                perc[j] = np.nanpercentile(V1_hcrit[:,j], Xth_corr[j]) # for a constant "v" (V1_vcrit[:,j]), percentile over depths...

    return perc

def nan_percentiles_bias_corr2(V1_vcrit, V1_hcrit, Xth):
    """
    This function obtains the nanpercentiles assuming that all nan correspond 
    to very high depth values (thus, biased).

    Parameters
    ----------
    V1_vcrit : velocity points of the stability curves.
    V1_hcrit : depths leading to unstable flow-vehicle configurations. Here 
        np.nan may exist.
    Xth : percentiled seeked.

    Returns
    -------
    perc : curve corresponding to the corrected-Xth percentile.

    """
    nx, ny = np.shape(V1_hcrit)
    
    count_nonnan_per_v = np.zeros(ny)
    Xth_corr = np.zeros(ny)
    
    perc = np.ones(ny)*np.nan
    
    for j in range(0,ny):
        # first, count how many values are not a NAN:
        count_nonnan_per_v[j] = np.count_nonzero(~np.isnan(V1_hcrit[:,j]))
        
        """
        If I am not correcting, given the top-missing data, Xth would be indeed
        calculating the Xth*count_nonnan_per_v/nx percentile. Thus, seraching 
        for Xth is wrong; i.e.: Xthwrong = Xth * count_nonnan_per_v/nx
        which means: 
            Xth = Xthwrong*nx/count_nonnan_per_v
        """
        
        if count_nonnan_per_v[j] == 0: # There is no non-nan value remaining!!
            Xth_corr[j] = np.nan
            perc[j] = np.nan
        else: # There are a few real values. Let's correct the percentile for missing-top values.
            Xth_corr[j] = Xth*nx/count_nonnan_per_v[j]
            
            if Xth_corr[j]>=100: # 100: # Oh, oh! Not many values remaining...
                Xth_corr[j] = np.nan
                perc[j] = np.nan
            else: # all good.
                perc[j] = np.nanpercentile(V1_hcrit[:,j], Xth_corr[j]) # for a constant "v" (V1_vcrit[:,j]), percentile over depths...

    return perc

def find_stable_config(Lx_list, Ly_list, Lz_list):
    
    N = len(Lx_list)
    
    for i in range(N):
        # order them
        L1 = np.max([Lx_list[i], Ly_list[i], Lz_list[i]])
        L2 = np.median([Lx_list[i], Ly_list[i], Lz_list[i]])
        L3 = np.min([Lx_list[i], Ly_list[i], Lz_list[i]])
        # reassign:
        Lx_list[i] = L1
        Ly_list[i] = L2
        Lz_list[i] = L3
        
    
    return Lx_list, Ly_list, Lz_list


def get_min_unstable_velocity(DM_vcrit, DM_hcrit):
    """
    This function gets the minimum velocity that leads to destabilization of an
    object. An object will be stable for any velocity below this one, regardless
    of the flow depth. This, then, only applies to heavier-than-water volumes.
    """
    nx, ny = np.shape(DM_vcrit)
    indx = np.zeros(nx, dtype=int)
    DM_vunst = np.zeros(nx)
    for i in range(nx):
        try:
            indx[i] = np.nanargmax(DM_hcrit[i,:])
            DM_vunst[i] = DM_vcrit[i, indx[i]]
        except Exception:
            DM_vunst[i] = np.nan

    return DM_vunst 


def get_var(folder, Nr, var_str):
    """
    Access the $var_str$.txt file in the specified folder and generates Nr samples
    following the predefined probability distribution.
    """
    
    file = folder + "//" + var_str + ".txt"
    with open(file) as f:
        csv.reader(file, delimiter='\t')
        lines = f.readlines()
    
    [Min, Mode, Max, Std, distr] = lines[1].split("\t")
    
    try: # Uniform or Triangular
        Min = float(Min); Max = float(Max); 
    except Exception:
        Min = []; Max = []
    try: # Triangular or Normal
        Mode = float(Mode)
    except Exception:
        Mode = []        
    try: # Normal
        Std = float(Std)
    except Exception:
        Std = []

    
    print("Parameter: ", var_str)
    print("Min \t Mode \t Max \t STD\n", [Min, Mode, Max, Std])

    if distr == "Uniform":
        if isinstance(Min, float):
            var_rand = np.random.uniform(Min,Max,Nr)
        else:
            d = Std*np.sqrt(3) # Assuming X \sim U distr, Var(X) =  (b-a)**2/12, d = STD*sqrt(3)
            a = 0 - d
            b = 0 + d
            var_rand = np.random.uniform(a,b,Nr)
    elif distr == "Triangular":
        var_rand = np.random.triangular(Min,Mode,Max,Nr)
    elif distr == "Normal":
        var_rand = np.random.normal(Mode,Std,Nr)
    else:
        print("Distribution not found for variable: ", var_str)
        var_rand = []
    
    return var_rand



# SOLVER ----------------------------------------------------------------------


def get_stability_curves_V1(M,Lx,Ly,Lz,zc,Cd,mu,fA_dev,fV2, nh,nv):
    
    fV1 = 0.00001
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 

    # Flotation limit state 

    Rz = M*g # Resistance
        
    fV = get_fV(fV1, fV2, h, zc, Lz)
    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    hflot = Rz/(rhow*g*fV*Lx*Ly)
    ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
    hcrit_flot = h[ZC[0]]

    # Sliding limit state:
    fA = get_fA_V1(h,Lz) *(1 + fA_dev) # MEAN * (1 + deviation)   //random deviation.
    
    fA[fA>1] = 1 # To avoid nonphysical results
    

    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths

            Sy[i,j] = 0.5 *(rhow*Cd*fA[j]*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j] # Sx
            RHSs[i,j] = mu*(Rz-Sz[j]) # Rx
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = zc + (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling


def get_stability_curves_V2(M,Lx,Ly,Lz,zc,Cd,mu,fA_dev,fV2, nh,nv):
    
    fV1 = 0.05
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 

    # Flotation limit state 

    Rz = M*g # Resistance
        
    fV = get_fV(fV1, fV2, h, zc, Lz)
    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    hflot = Rz/(rhow*g*fV*Lx*Ly)
    ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
    hcrit_flot = h[ZC[0]]

    # Sliding limit state:
    fA = get_fA_V2(h,Lz) *(1 + fA_dev) # MEAN * (1 + deviation)   //random deviation.
    
    fA[fA>1] = 1 # To avoid nonphysical results
    

    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths

            Sy[i,j] = 0.5 *(rhow*Cd*fA[j]*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j]
            RHSs[i,j] = mu*(Rz-Sz[j])
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = zc + (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling


def get_stability_curves_V3(M,Lx,Ly,Lz,zc,Cd,mu,fA_dev,fV2, nh,nv):
    
    fV1 = 0.05
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 

    # Flotation limit state 

    Rz = M*g # Resistance
        
    fV = get_fV(fV1, fV2, h, zc, Lz)
    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    hflot = Rz/(rhow*g*fV*Lx*Ly)
    ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
    hcrit_flot = h[ZC[0]]

    # Sliding limit state:
    fA = get_fA_V3(h,Lz) *(1 + fA_dev) # MEAN * (1 + deviation)   //random deviation.
    
    fA[fA>1] = 1 # To avoid nonphysical results
    

    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths

            Sy[i,j] = 0.5 *(rhow*Cd*fA[j]*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j]
            RHSs[i,j] = mu*(Rz-Sz[j])
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = zc + (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling


def get_stability_curves_V4(M,Lx,Ly,Lz,zc,Cd,mu,fA_dev,fV2, nh,nv):
    
    fV1 = 0.05
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 

    # Flotation limit state 

    Rz = M*g # Resistance
        
    fV = get_fV(fV1, fV2, h, zc, Lz)
    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    hflot = Rz/(rhow*g*fV*Lx*Ly)
    ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
    hcrit_flot = h[ZC[0]]

    # Sliding limit state:
    fA = get_fA_V4(h,Lz) *(1 + fA_dev) # MEAN * (1 + deviation)   //random deviation.
    
    fA[fA>1] = 1 # To avoid nonphysical results
    

    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths

            Sy[i,j] = 0.5 *(rhow*Cd*fA[j]*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j]
            RHSs[i,j] = mu*(Rz-Sz[j])
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = zc + (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling


def get_stability_curves_V5(M,Lx,Ly,Lz,zc,Cd,mu,fA_dev,fV2, nh,nv):
    
    fV1 = 0.05
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 

    # Flotation limit state 

    Rz = M*g # Resistance
        
    fV = get_fV(fV1, fV2, h, zc, Lz)
    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    hflot = Rz/(rhow*g*fV*Lx*Ly)
    ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
    hcrit_flot = h[ZC[0]]

    # Sliding limit state:
    fA = get_fA_V5(h,Lz) *(1 + fA_dev) # MEAN * (1 + deviation)   //random deviation.
    
    fA[fA>1] = 1 # To avoid nonphysical results
    

    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths

            Sy[i,j] = 0.5 *(rhow*Cd*fA[j]*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j]
            RHSs[i,j] = mu*(Rz-Sz[j])
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = zc + (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling



def get_stability_curves_debris(M,Lx,Ly,Lz,zc,Cd,mu,fA,fV,nh,nv):
    
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 

    # Flotation limit state 

    Rz = M*g # Resistance    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    if rhow*fV*Lx*Ly*Lz > M: # displaced water weight larger than weight of the object? then hcrit at some depth.
        
        hflot = Rz/(rhow*g*fV*Lx*Ly)
        ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
        hcrit_flot = h[ZC[0]]
    else: # It is heavier than water, it will not float
        hcrit_flot = np.nan

    # Sliding limit state:

    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths
            
            Sy[i,j] = 0.5 *(rhow*Cd*fA*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j] # Sy
            RHSs[i,j] = mu*(Rz-Sz[j]) # Ry
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling



def get_stability_curves_F1(M,Lx,Ly,Lz,zc,Cd,mu,fA_dev,nh,nv):
    
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 
    fA = get_fA_F1(h,Lz) *(1 + fA_dev) # MEAN * (1 + deviation)   //random deviation.
    
    fA[fA>1] = 1 # To avoid nonphysical results
    fV = (fA)**(3/2)
    
    # Flotation limit state 

    Rz = M*g # Resistance    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    if rhow*np.max(fV)*Lx*Ly*Lz > M: # displaced water weight larger than weight of the object? then hcrit at some depth.
        
        hflot = Rz/(rhow*g*fV*Lx*Ly)
        ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
        hcrit_flot = h[ZC[0]]
    else: # It is heavier than water, it will not float
        hcrit_flot = np.nan

    # Sliding limit state:

    
    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths
            
            Sy[i,j] = 0.5 *(rhow*Cd*fA[j]*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j]
            RHSs[i,j] = mu*(Rz-Sz[j])
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling


def get_stability_curves_F2(M,Lx,Ly,Lz,zc,Cd,mu,fA_dev,nh,nv):
    
    g = 9.8
    rhow = 998
    # h, vx as key parameters
    # nh = 200; nv = 400
    h = np.linspace(0, Lz, nh)
    v = np.linspace(0, 9.5, nv)
    # 
    # Start calculations 
    fA = get_fA_F2(h,Lz) *(1 + fA_dev) # MEAN * (1 + deviation)   //random deviation.
    
    fA[fA>1] = 1 # To avoid nonphysical results
    fV = (fA)**(3/2)
    
    # Flotation limit state 

    Rz = M*g # Resistance    
    Sz = rhow*g*fV*h*Lx*Ly # Load

    if rhow*np.max(fV)*Lx*Ly*Lz > M: # displaced water weight larger than weight of the object? then hcrit at some depth.
        
        hflot = Rz/(rhow*g*fV*Lx*Ly)
        ZC = np.where(np.diff(np.sign(hflot-h)))[0] # zero crossings
        hcrit_flot = h[ZC[0]]
    else: # It is heavier than water, it will not float
        hcrit_flot = np.nan

    # Sliding limit state:

    
    H, V = np.meshgrid(h,v)
    LHSs = np.zeros_like(H); RHSs = np.zeros_like(H)
    Sy = np.zeros_like(H)
    for i in range(0, nv): # - velocity
        for j in range(0, nh): # - depths
            
            Sy[i,j] = 0.5 *(rhow*Cd*fA[j]*Lx*H[i,j]*V[i,j]*V[i,j])
            LHSs[i,j] = Sy[i,j]
            RHSs[i,j] = mu*(Rz-Sz[j])
            
            
    # Toppling limit state

    LHSt = np.zeros_like(H); RHSt = np.zeros_like(H)
    for i in range(0, nv):
        for j in range(0, nh):
           
            if H[i,j] > zc:
                zp = (H[i,j]-zc)/2
            else:
                zp = (H[i,j])/2
            yp = Ly/2
            
            LHSt[i,j] = Sy[i,j]*zp + Sz[j]*yp
            RHSt[i,j] = Rz*Ly/2
            
    """
    I need a zero-finding routine to map:
        - sliding: LHSs-RHSs
        - toppling: LHSt-RHSt
    """
    # Slidding:
    arr_sliding = LHSs-RHSs        
    hcrit_sliding = zero_finding2(arr_sliding, v, h)
    # Toppling:
    arr_toppling = LHSt-RHSt        
    hcrit_toppling = zero_finding2(arr_toppling, v, h)

    return hcrit_flot, v, hcrit_sliding, v, hcrit_toppling

# Limit state: flotation -----------------------------------------------------

def get_fV(fV1, fV2, h, zc, Lz):
    """
    gets the eta paramerter, related to the percentage of underfloor area wetted.

    h: water level (vector).
    z_uf: elevation of the underfloor relative to the street level.
    Lz: height of the boundaing box.
    """
    # fV1 = 0.05 # MIN percentage of bounding box area submerged, below clearance.
    # 0.075 full wheels, if they were a solid squared block
    
    
    fV = np.zeros_like(h)
    for i in range(0, len(h)):
        if h[i]<zc: # below the car underfloor
            fV[i] = fV1 # wheels.
        elif h[i]<Lz: # over the car underfloor, and up to the car height
            if h[i] > 0:
                fV[i] = (fV1*zc + fV2*(h[i]-zc)) / h[i]
            else:
                fV[i] = fV2
            
        else: # over the car height
            fV[i] = np.nan
    
    return fV


# Limit state: sliding 


def get_fA_V1(h,Lz):
    """
    This function obtains the projected wetted area in the frontal direction
    for the case of bikes and motorbikes. Total area:
        Axz = fA*Lx*Lz
        
        fA = a0 + a1*x + a2*x**2 + a3*x**3 
    """
        
    a0 = 0.182296 # zero-order param
    a1 = 2.094 # first-order param
    a2 = -3.001 # second-order param
    a3 = 1.274 # third-order param
    # a4 = 0 # fourth-order param
    
    fA = a0 + a1*(h/Lz) + a2*(h/Lz)**2 + a3*(h/Lz)**3 #+ a4*(h/Lz)**4 
    
    return fA


def get_fA_V2(h,Lz):
    """
    This function obtains the projected wetted area in the frontal direction
    for the case of a car. This is based on analysis of side images of cars.
    Total area:
        Axz = fA*Lx*Lz
        
        fA = a0 + a1*x + a2*x**2 + a3*x**3 
    """
        
    a0 = -0.010491 # zero-order param
    a1 = 2.761454 # first-order param
    a2 = -2.904696 # second-order param
    a3 = 0.845684 # third-order param
    # a4 = 0 # fourth-order param
    
    fA = a0 + a1*(h/Lz) + a2*(h/Lz)**2 + a3*(h/Lz)**3 #+ a4*(h/Lz)**4 
    
    return fA


def get_fA_V3(h,Lz):
    """
    This function obtains the projected wetted area in the frontal direction
    for the case of vans. Total area:
        Axz = fA*Lx*Lz
        
        fA = a0 + a1*x + a2*x**2 + a3*x**3 
    """
        
    a0 = -0.017 # zero-order param
    a1 = 2.926269 # first-order param
    a2 = -3.390306 # second-order param
    a3 = 1.254274 # third-order param
    # a4 = 0 # fourth-order param
    
    fA = a0 + a1*(h/Lz) + a2*(h/Lz)**2 + a3*(h/Lz)**3 #+ a4*(h/Lz)**4 
    
    return fA


def get_fA_V4(h,Lz):
    """
    This function obtains the projected wetted area in the frontal direction
    for the case of caravans and RVs. Total area:
        Axz = fA*Lx*Lz
        
        fA = a0 + a1*x + a2*x**2 + a3*x**3 
    """
        
    a0 = -0.036 # zero-order param
    a1 = 3.179 # first-order param
    a2 = -4.037 # second-order param
    a3 = 1.694 # third-order param
    # a4 = 0 # fourth-order param
    
    fA = a0 + a1*(h/Lz) + a2*(h/Lz)**2 + a3*(h/Lz)**3 #+ a4*(h/Lz)**4 
    
    return fA


def get_fA_V5(h,Lz):
    """
    This function obtains the projected wetted area in the frontal direction
    for the case of a truck or bus.
    Total area:
        Axz = fA*Lx*Lz
        
        fA = a0 + a1*x + a2*x**2 + a3*x**3 
    """
        
    a0 = -0.008078 # zero-order param
    a1 = 2.542862 # first-order param
    a2 = -2.546188 # second-order param
    a3 = 0.839500 # third-order param
    # a4 = 0 # fourth-order param
    
    fA = a0 + a1*(h/Lz) + a2*(h/Lz)**2 + a3*(h/Lz)**3 #+ a4*(h/Lz)**4 
    
    return fA

def get_fA_F1(h,Lz):
    """
    This function obtains the projected wetted area in the frontal direction
    for the case of urban furniture. Total area:
        Axz = fA*Lx*Lz
        
        fA = a0 + a1*x + a2*x**2 + a3*x**3 
    """
        
    a0 = 0.430933 # zero-order param
    a1 = 1.558 # first-order param
    a2 = -2.232 # second-order param
    a3 = 1.087 # third-order param
    # a4 = 0 # fourth-order param
    
    fA = a0 + a1*(h/Lz) + a2*(h/Lz)**2 + a3*(h/Lz)**3 #+ a4*(h/Lz)**4 
    
    return fA

def get_fA_F2(h,Lz):
    """
    This function obtains the projected wetted area in the frontal direction
    for the case of private furniture. Total area:
        Axz = fA*Lx*Lz
        
        fA = a0 + a1*x + a2*x**2 + a3*x**3 
    """
        
    a0 = 0.530116 # zero-order param
    a1 = 2.440216 # first-order param
    a2 = -4.135 # second-order param
    a3 = 2.1225 # third-order param
    # a4 = 0 # fourth-order param
    
    fA = a0 + a1*(h/Lz) + a2*(h/Lz)**2 + a3*(h/Lz)**3 #+ a4*(h/Lz)**4 
    
    return fA

# Limit state: toppling ------------------------------------------------------